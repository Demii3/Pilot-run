<style>
  #employeeTable {
    font-size: 0.92rem;
    width: 100%;
    min-width: 100%;
    table-layout: fixed;
  }

  #employeeTable th,
  #employeeTable td {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  #employeeTable th {
    background-color: #f8f9fa;
  }

  .table-responsive {
    overflow-x: auto;
  }
</style>

<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center">
    <h2>Manage Employees</h2>
    <div>
      <button class="btn btn-info me-2" onclick="document.getElementById('importFile').click()">Import from Excel</button>
      <input type="file" id="importFile" accept=".csv,.xlsx,.xls" style="display: none;" onchange="importFromExcel(this)">
      <button class="btn btn-success me-2" onclick="exportToExcel()">Export to Excel</button>
      <button class="btn btn-primary add-employee-btn" onclick="openAddForm()">+ Add Employee</button>
    </div>
  </div>

  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-hover" id="employeeTable"></table>
    </div>
  </div>
</div>

<div id="employeeModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h2 id="formTitle">Add New Employee</h2>
      <span class="close" onclick="closeModal()">&times;</span>
    </div>

    <form id="employeeForm">
      <input type="hidden" id="employeeId">

      <div class="form-group">
        <label for="name">Full Name:</label>
        <input type="text" id="name" class="form-control" required>
      </div>

      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" class="form-control" required>
      </div>

      <div class="form-group">
        <label for="username">Username:</label>
        <input type="text" id="username" class="form-control" required>
      </div>

      <div class="form-group">
        <label for="password">Password:</label>
        <input type="password" id="password" class="form-control">
      </div>

      <div class="form-group">
        <label for="type">Type:</label>
        <select id="type" class="form-control" required>
          <option value="HR">HR</option>
          <option value="Emp">Emp</option>
        </select>
      </div>

      <div class="form-group">
        <label for="position">Position:</label>
        <input type="text" id="position" class="form-control" required>
      </div>

      <div class="form-group">
        <label for="department">Department:</label>
        <input type="text" id="department" class="form-control" required>
      </div>

      <div class="form-group">
        <label for="salary">Salary:</label>
        <input type="number" id="salary" class="form-control" step="0.01" required>
      </div>

      <div class="form-group">
        <label for="joinDate">Join Date:</label>
        <input type="date" id="joinDate" class="form-control" required>
      </div>

      <div class="form-group">
        <label for="status">Status:</label>
        <select id="status" class="form-control" required>
          <option value="Active">Active</option>
          <option value="Inactive">Inactive</option>
        </select>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Employee</button>
      </div>
    </form>
  </div>
</div>