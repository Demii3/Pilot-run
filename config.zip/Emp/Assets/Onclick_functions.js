
const proceedButton = document.getElementById('proceedToAttendance');
const attendanceBtn = document.getElementById('attendanceBtn');
const logoutButton = document.getElementById('logout');
const empLocationLat = document.getElementById('empLocationLat');
const empLocationLng = document.getElementById('empLocationLng');
const settings = document.getElementById('settingsLink');
let map; // Declare map variable in a scope accessible to all functions
let markers; // Declare marker variable to manage the marker on the map
let geofenceLayer;

function showLocationErrorModal(message) {
    const modalElement = document.getElementById('locationErrorModal');
    const modalBody = document.getElementById('locationErrorMessage');
    
    if (modalBody) {
        modalBody.textContent = message;
    }
    
    if (modalElement && window.bootstrap && bootstrap.Modal) {
        const modal = new bootstrap.Modal(modalElement, { backdrop: false, keyboard: true });
        modal.show();
    }
}

function loadAttendanceContent() {
    const content = document.getElementById('content-area');
    const payload = { TEST: 'This is a string', USER_ID: document.getElementById('userId').value };

    fetch('./Modules/test.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    })
    .then(response => {
        if (!response.ok) throw new Error('Failed to load content');
        if (response.error) throw new Error(response.error); // Handle no content response
        return response.json();
    })
    .then(data => { 
        content.innerHTML = data.datafile; // Assuming the response contains a property 'datafile' with the HTML content
        console.log('Received data:', data);
        fillspans(); // Call the function to fill spans after loading the content
        return getUserLocation().then(() => data);
    })
    .then((data) => {
        if (data.error) {
            console.error('Error:', data.error);
            content.innerHTML = '<p style="color: red;">Failed to load content. Please try again later.</p>';
        } else {
            applymap(data.querydata); // Call the function to initialize the map after loading the content
            setAttendanceModuleProperties(data.querydata); // Set properties for attendance module buttons
        }
    })
    .catch(error => {
        console.error('Error:', error);
        content.innerHTML = '<p style="color: red;">Failed to load content. Please try again later.</p>';
    });
}

function loadEmpInfoContent() {
    const content = document.getElementById('content-area');
    const payload = { TEST: 'This is a string', USER_ID: document.getElementById('userId').value };

    fetch('./Modules/test2.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    })
    .then(response => {
        if (!response.ok) throw new Error('Failed to load content');
        if (response.error) throw new Error(response.error); // Handle no content response
        return response.json();
    })
    .then(data => { 
        console.log('Received data:', data);
        content.innerHTML = data.datafile; // Assuming the response contains a property 'datafile' with the HTML content
        populateEmpInfo(data.querydata); // Call the function to populate employee info after loading the content
    })
    .catch(error => {
        console.error('Error:', error);
        content.innerHTML = '<p style="color: red;">Failed to load content. Please try again later.</p>';
    });
}

function populateEmpInfo(querydata) {
    const name = document.getElementById('name');
    const department = document.getElementById('department');
    const email = document.getElementById('email');
    const username = document.getElementById('Username');
    const Username = document.getElementById('userName');

    if (name) name.value = querydata.name || '';
    if (department) department.value = querydata.department || '';
    if (email) email.value = querydata.email || '';
    if (username) username.value = querydata.username || '';
    if (Username) Username.textContent = querydata.name || 'User';
}

if (attendanceBtn) {
    attendanceBtn.addEventListener('click', loadAttendanceContent);
};

if (proceedButton) {
    proceedButton.addEventListener('click', loadAttendanceContent);
};

if (settings) {
    settings.addEventListener('click', loadEmpInfoContent);
}


function getUserLocation() {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
            console.log('Geolocation is not supported by this browser.');
            return;
        }

        navigator.geolocation.getCurrentPosition(
            (position) => {
                empLocationLat.value = position.coords.latitude;
                empLocationLng.value = position.coords.longitude;

                console.log('Latitude:', empLocationLat.value);
                console.log('Longitude:', empLocationLng.value);

                const empLocation = document.getElementById('empLocation');
                if (empLocation) {
                    empLocation.value = `${empLocationLat.value},${empLocationLng.value}`;
                }
                resolve();
            },
            (error) => {
                console.error('Location error:', error.message);
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
        );
    });
}

function applymap(querydata) {
    const MapContainer = document.getElementById('Map-container');
    if (!MapContainer || typeof L === 'undefined') return;

    if (map) {
        // Map already exists, just update its view and marker
        map.setView([parseFloat(empLocationLat.value), parseFloat(empLocationLng.value)], 18);
        L.marker([parseFloat(empLocationLat.value), parseFloat(empLocationLng.value)]).addTo(markers);
        return;
    }

    map = L.map(MapContainer).setView([parseFloat(empLocationLat.value), parseFloat(empLocationLng.value)], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    markers = L.layerGroup().addTo(map);

    L.marker([parseFloat(empLocationLat.value), parseFloat(empLocationLng.value)]).addTo(markers);
};

function drawGeofence(coords) {
    if (!map || !Array.isArray(coords) || coords.length < 3) return;
    console.log('Drawing geofence with coordinates:', coords);

    if (geofenceLayer) {
        geofenceLayer.remove();
    }

    geofenceLayer = L.polygon(coords, {
        color: 'blue',
        fillColor: '#3388ff',
        fillOpacity: 0.2
    }).addTo(map);

    map.fitBounds(geofenceLayer.getBounds());
}

function parseGeofenceCoordinates(rawCoordinates) {
    if (!rawCoordinates) {
        return [];
    }

    try {
        const firstParse = typeof rawCoordinates === 'string' ? JSON.parse(rawCoordinates) : rawCoordinates;
        const coordinates = typeof firstParse === 'string' ? JSON.parse(firstParse) : firstParse;

        if (!Array.isArray(coordinates)) {
            return [];
        }

        return coordinates
            .map((point) => {
                if (!Array.isArray(point) || point.length < 2) {
                    return null;
                }

                const lat = parseFloat(point[0]);
                const lng = parseFloat(point[1]);
                if (Number.isNaN(lat) || Number.isNaN(lng)) {
                    return null;
                }

                return [lat, lng];
            })
            .filter(Boolean);
    } catch (error) {
        console.error('Invalid geofence coordinates:', error);
        return [];
    }
}

function isPointInPolygon(point, polygon) {
    const x = point[1];
    const y = point[0];
    let isInside = false;

    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
        const xi = polygon[i][1];
        const yi = polygon[i][0];
        const xj = polygon[j][1];
        const yj = polygon[j][0];

        const intersects = ((yi > y) !== (yj > y))
            && (x < (xj - xi) * (y - yi) / ((yj - yi) || Number.EPSILON) + xi);

        if (intersects) {
            isInside = !isInside;
        }
    }

    return isInside;
}

function isUserWithinGeofence(rawCoordinates) {
    const userLat = parseFloat(empLocationLat.value);
    const userLng = parseFloat(empLocationLng.value);

    if (Number.isNaN(userLat) || Number.isNaN(userLng)) {
        return false;
    }

    const polygon = parseGeofenceCoordinates(rawCoordinates);
    if (polygon.length < 3) {
        return false;
    }

    return isPointInPolygon([userLat, userLng], polygon);
}


function setAttendanceModuleProperties(querydata) {
    console.log('Setting attendance module properties with querydata:', querydata);
    const returnToHomeButton = document.getElementById('returnToHome');
    const refreshLocationButton = document.getElementById('refreshLocation');
    const tapInButton = document.getElementById('tapIn');
    const locationSelect = document.getElementById('locationSelect');
    const attendanceIdInput = document.getElementById('attendanceId');
    attendanceIdInput.value = querydata.Attendance_id || '';

    function parseJsonList(rawValue) {
        if (!rawValue) {
            return [];
        }

        if (Array.isArray(rawValue)) {
            return rawValue;
        }

        try {
            const parsedValue = JSON.parse(rawValue);
            return Array.isArray(parsedValue) ? parsedValue : [];
        } catch (error) {
            return [];
        }
    }

    if (locationSelect) {
        const locationsData = parseJsonList(document.getElementById('locations')?.value);
        const coordinatesData = parseJsonList(document.getElementById('coordinates')?.value);

        locationsData.forEach((location, index) => {
            const option = document.createElement('option');
            option.value = location;
            option.textContent = location;

            if (coordinatesData[index]) {
                option.setAttribute('data-coordinates', JSON.stringify(coordinatesData[index]));
            }

            locationSelect.appendChild(option);
        });

        if (querydata.Work_Status == 'Tapped-in') {
            locationSelect.value = querydata.Location; // Set to the first location if already tapped in
            locationSelect.disabled = true;
        }
    }

    locationSelect.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        const coordinates = selectedOption.getAttribute('data-coordinates');
        if (coordinates) {
            drawGeofence(JSON.parse(JSON.parse(coordinates)));
        }
    });

    if(tapInButton) {
        tapInButton.addEventListener('click', TapIn);

            if (querydata.Work_Status == 'Tapped-in') {
                tapInButton.innerText = 'Tap Out';
                tapInButton.classList.remove('btn-success');
                tapInButton.removeEventListener('click', TapIn);
                tapInButton.classList.add('btn-danger');
                tapInButton.addEventListener('click', TapOut);
            }
    }

    if(refreshLocationButton) {
        refreshLocationButton.addEventListener('click', function() {
            getUserLocation().then(() => {
                markers.clearLayers(); // Clear existing markers
                applymap(querydata = 0); // Re-apply the map to update the marker position
            });
        });
    }

    if (returnToHomeButton) {
        returnToHomeButton.addEventListener('click', function() {
            window.location = './index.php';
        });
    }

    if (querydata == 0) {
        return;
        };

    if (querydata.Work_Status == 'Tapped-in') {
        drawGeofence(JSON.parse(JSON.parse(querydata.Coordinates)));
    };
}

async function TapIn() {
    const selectedOption = locationSelect.options[locationSelect.selectedIndex];
    if (!selectedOption) {
        showLocationErrorModal('Please select a location first');
        return;
    }

    const locationName = selectedOption.value;
    const coordinates = selectedOption.getAttribute('data-coordinates');

    if (locationName && coordinates) {
        if (!isUserWithinGeofence(coordinates)) {
            const confirmed = await showConfirmationModal('You are outside the selected geofence area. Do you want to proceed with Tap In?');
            if (!confirmed) {
                return;
            }
        }

        saveTimeIn();
    } else {
        showLocationErrorModal('Please select a location first');
    };
}

async function TapOut() {
    const selectedOption = locationSelect.options[locationSelect.selectedIndex];
    if (!selectedOption) {
        showLocationErrorModal('Please select a location first');
        return;
    }

    const locationName = selectedOption.value;
    const coordinates = selectedOption.getAttribute('data-coordinates');

    if (locationName && coordinates) {
        if (!isUserWithinGeofence(coordinates)) {
            const confirmed = await showConfirmationModal('You are outside the selected geofence area. Do you want to proceed with Tap Out?');
            if (!confirmed) {
                return;
            }
        }

        saveTimeOut();
    }
}
